#!/usr/bin/env python3
"""Local launcher: serves only this prototype, bound to this Mac."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from functools import partial
import webbrowser

root = Path(__file__).resolve().parent
handler = partial(SimpleHTTPRequestHandler, directory=str(root))
server = None
for port in range(8765, 8780):
    try:
        server = ThreadingHTTPServer(('127.0.0.1', port), handler)
        break
    except OSError:
        continue
if server is None:
    raise SystemExit('Impossible de démarrer le serveur local. Ferme un ancien lancement et réessaie.')
url = 'http://127.0.0.1:%d/' % server.server_port
print('Recmachine Monitor est disponible sur ' + url)
print('Garde cette fenêtre ouverte pendant la séance. Ctrl+C pour arrêter.')
webbrowser.open(url)
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
