/* Pure geometry, shared by app, worker and tests. */
(function(root){
 const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 function analyze(data,w,h){
  const gray=new Float32Array(w*h),cols=new Float32Array(w),rows=new Float32Array(h),cells=new Float32Array(96);
  for(let i=0;i<w*h;i++)gray[i]=.299*data[i*4]+.587*data[i*4+1]+.114*data[i*4+2];
  let left=0,right=0,total=0;
  for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){
   let i=y*w+x,gx=gray[i+1]-gray[i-1],gy=gray[i+w]-gray[i-w],e=Math.hypot(gx,gy);
   cells[Math.min(7,Math.floor(y/h*8))*12+Math.min(11,Math.floor(x/w*12))]+=e;total+=e;
   if(x<w/2)left+=e;else right+=e;
   if(Math.abs(gx)>Math.abs(gy)*2)cols[x]+=Math.abs(gx);
   if(Math.abs(gy)>Math.abs(gx)*2)rows[y]+=Math.abs(gy);
  }
  function peaks(values,n){let candidates=[];for(let i=3;i<values.length-3;i++)if(values[i]>values[i-1]&&values[i]>=values[i+1]&&values[i]>n*12)candidates.push({p:i/values.length,strength:values[i]/n});candidates.sort((a,b)=>b.strength-a.strength);let out=[];for(const c of candidates)if(out.every(t=>Math.abs(c.p-t.p)>.07)&&out.length<4)out.push(c);return out}
  return {verticals:peaks(cols,h),horizontals:peaks(rows,w),left,right,cells:Array.from(cells),density:total/(w*h)};
 }
 function axis(scene){if(!scene)return null;const v=scene.verticals;let best=null,score=0;for(let i=0;i<v.length;i++)for(let j=i+1;j<v.length;j++){let gap=Math.abs(v[i].p-v[j].p),s=Math.min(v[i].strength,v[j].strength);if(gap>.2&&s>score){best=(v[i].p+v[j].p)/2;score=s}}return best}
 function target(mode,scene,side){let right=side==='right'||(side==='auto'&&(!scene||(scene.preferredSide?scene.preferredSide==='right':scene.right<=scene.left)));return {x:mode==='symmetry'?.5:right?1/3:2/3,y:mode==='space'?.36:.22}}
 function propose(mode,box,scene,aspect,ratio,amount,side){
  let t=target(mode,scene,side),w=amount,h=w*aspect/ratio;if(h>amount){h=amount;w=h*ratio/aspect}
  let anchor=box?{x:box.x+box.w/2,y:box.y+box.h*.1}:{x:.5,y:.42};
  const architecturalAxis=axis(scene);if(mode==='symmetry'&&architecturalAxis!==null)anchor.x=architecturalAxis;
  if(box&&w<box.w*1.16){w=Math.min(1,box.w*1.16);h=w*aspect/ratio;if(h>1){h=1;w=ratio/aspect}}
  let x=clamp(anchor.x-w*t.x,0,1-w),y=clamp(anchor.y-h*t.y,0,1-h);
  if(box&&box.h>0){y=clamp(Math.min(y,box.y-h*.06),0,1-h);if(box.w<=w&&mode!=='symmetry')x=clamp(x,Math.max(0,box.x+box.w-w),Math.min(box.x,1-w))}
  let clipped=!!box&&(box.x<x||box.x+box.w>x+w||box.y<y);
  return {x,y,w,h,target:t,clipped};
 }
 function match(previous,items){if(!previous)return null;let best=null,bestScore=0;for(const b of items){if(b.label!==previous.label)continue;let ix=Math.max(0,Math.min(b.x+b.w,previous.x+previous.w)-Math.max(b.x,previous.x)),iy=Math.max(0,Math.min(b.y+b.h,previous.y+previous.h)-Math.max(b.y,previous.y));let overlap=ix*iy/(b.w*b.h+previous.w*previous.h-ix*iy||1),distance=Math.hypot(b.x+b.w/2-previous.x-previous.w/2,b.y+b.h/2-previous.y-previous.h/2);let score=overlap+.25-distance;if(distance<.22&&score>bestScore){best=b;bestScore=score}}return best}
 root.CineMath={clamp,analyze,axis,target,propose,match};
})(typeof self!=='undefined'?self:globalThis);
