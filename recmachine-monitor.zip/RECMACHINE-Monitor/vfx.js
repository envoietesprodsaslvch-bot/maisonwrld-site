/* Non-destructive live preview effects. Never used as detector input. */
(function(root){
 let previous=null,previousKey=null,lastTime=0;const noise=document.createElement('canvas');noise.width=noise.height=128;const nc=noise.getContext('2d'),pixels=nc.createImageData(128,128);let seed=73;for(let i=0;i<pixels.data.length;i+=4){seed=(seed*1664525+1013904223)>>>0;let v=seed>>>24;pixels.data[i]=pixels.data[i+1]=pixels.data[i+2]=v;pixels.data[i+3]=255}nc.putImageData(pixels,0,0);
 function reset(){previous=null;previousKey=null;lastTime=0}
 function apply(c,settings,key){const ctx=c.getContext('2d'),w=c.width,h=c.height,t=performance.now();if(settings.echo&&previous&&previousKey===key&&t-lastTime<250){ctx.save();ctx.globalAlpha=.3;ctx.drawImage(previous,0,0,w,h);ctx.restore()}if(settings.echo){if(!previous){previous=document.createElement('canvas')}previous.width=w;previous.height=h;previous.getContext('2d').drawImage(c,0,0);previousKey=key;lastTime=t}else reset();
 if(settings.glow&&'filter' in ctx){ctx.save();ctx.globalCompositeOperation='screen';ctx.globalAlpha=.3;ctx.filter='brightness(1.08) contrast(1.45) blur('+Math.max(2,w*.008)+'px)';ctx.drawImage(c,0,0);ctx.restore()}
 if(settings.vignette){const g=ctx.createRadialGradient(w*.5,h*.45,Math.min(w,h)*.22,w*.5,h*.5,Math.hypot(w,h)*.55);g.addColorStop(0,'#0000');g.addColorStop(1,'#000b');ctx.fillStyle=g;ctx.fillRect(0,0,w,h)}
 if(settings.grain){ctx.save();ctx.globalAlpha=.12;ctx.globalCompositeOperation='soft-light';const pattern=ctx.createPattern(noise,'repeat');ctx.fillStyle=pattern;ctx.translate((Math.floor(t/70)*19)%128,(Math.floor(t/70)*7)%128);ctx.fillRect(-128,-128,w+256,h+256);ctx.restore()}
 }
 root.CineVFX={apply,reset};
})(window);
