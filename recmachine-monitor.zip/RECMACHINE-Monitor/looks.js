/* Creative display filters; not color-managed camera profile transforms. */
(function(root){
 const presets={neutral:{},cinema:{contrast:1.22,saturate:.82,brightness:.97},warm:{sepia:.32,saturate:1.12,contrast:1.08,brightness:1.03},cool:{sepia:.2,hue:165,saturate:.85,contrast:1.12,brightness:.98},pastel:{contrast:.82,saturate:.76,brightness:1.12},mono:{grayscale:1,contrast:1.18}};
 function filter(name,strength,original=false){const p=presets[name]||presets.neutral,t=Math.max(0,Math.min(1,Number(strength)/100||0));if(original||!t||name==='neutral')return 'none';const interpolate=(key,base)=>base+((p[key]??base)-base)*t;return 'brightness('+interpolate('brightness',1)+') contrast('+interpolate('contrast',1)+') saturate('+interpolate('saturate',1)+') sepia('+interpolate('sepia',0)+') hue-rotate('+interpolate('hue',0)+'deg) grayscale('+interpolate('grayscale',0)+')'}
 root.CineLooks={presets,filter};
})(typeof self!=='undefined'?self:globalThis);
