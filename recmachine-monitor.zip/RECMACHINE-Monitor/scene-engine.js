/* Local scene measurements and candidate search. Scores are rules, not aesthetic predictions. */
(function(root){
 const M=root.CineMath;
 function measure(data,w,h,objects){
  const cells=Array.from({length:96},()=>({edge:0,luma:0,hot:0,dark:0,n:0}));let hot=0,dark=0,sum=0;
  const lum=i=>.2126*data[i]+.7152*data[i+1]+.0722*data[i+2];
  for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){let i=(y*w+x)*4,l=lum(i),edge=Math.abs(lum(i+4)-lum(i-4))+Math.abs(lum(i+w*4)-lum(i-w*4)),c=cells[Math.floor(y/h*8)*12+Math.floor(x/w*12)];c.n++;c.edge+=edge;c.luma+=l;c.hot+=l>245?1:0;c.dark+=l<18?1:0;hot+=l>245?1:0;dark+=l<18?1:0;sum+=l}
  for(const c of cells)for(const k of ['edge','luma','hot','dark'])c[k]/=c.n||1;
  const background=side=>{let total=0,n=0;for(let j=0;j<96;j++){let x=(j%12+.5)/12,y=(Math.floor(j/12)+.5)/8;if((side==='left')!==(x<.5))continue;if(objects.some(b=>b.label==='person'&&x>b.x&&x<b.x+b.w&&y>b.y&&y<b.y+b.h))continue;total+=cells[j].edge;n++}return n?total/n:0};
  const n=(w-2)*(h-2);return {tiles:cells,highlightFraction:hot/n,shadowFraction:dark/n,meanLight:sum/n,backgroundLeft:background('left'),backgroundRight:background('right')};
 }
 function anchor(box){return box?.face?{x:box.face.x+box.face.w/2,y:box.face.eyeY??box.face.y+box.face.h*.42}:{x:box.x+box.w/2,y:box.y+box.h*.1}}
 function protectedHead(box){if(!box||!box.h)return null;return box.face||{x:box.x+box.w*.15,y:box.y,w:box.w*.7,h:box.h*.18}}
 function score(p,box,scene,mode){let value=0;const a=box?anchor(box):{x:.5,y:.4},head=protectedHead(box);let localX=(a.x-p.x)/p.w,localY=(a.y-p.y)/p.h;
  value-=Math.abs(localX-p.target.x)*15+Math.abs(localY-p.target.y)*9;
  if(head){let margin=.015; if(head.x<p.x+margin*p.w||head.x+head.w>p.x+p.w-margin*p.w||head.y<p.y+margin*p.h||head.y+head.h>p.y+p.h-margin*p.h)value-=80;else value+=12}
  if(box&&box.w>0){let visible=Math.max(0,Math.min(box.x+box.w,p.x+p.w)-Math.max(box.x,p.x))/box.w;value-=(1-visible)*45;const fill=box.h/p.h;value-=Math.abs(fill-(mode==='space'?.65:mode==='portrait'?1.8:1))*3}
  let clutter=0,light=0,n=0;
  for(let j=0;j<(scene?.tiles?.length||0);j++){let x=(j%12+.5)/12,y=(Math.floor(j/12)+.5)/8;if(x<p.x||x>p.x+p.w||y<p.y||y>p.y+p.h)continue;if(box&&x>box.x&&x<box.x+box.w&&y>box.y&&y<box.y+box.h)continue;clutter+=scene.tiles[j].edge;light+=scene.tiles[j].hot;n++}
  if(n){value-=clutter/n*.035+light/n*9}return value;
 }
 function propose(mode,box,scene,aspect,ratio,amount,side){let best=null;for(const scale of [amount,Math.min(1,amount*1.12),Math.max(.3,amount*.9)]){
  let p=M.propose(mode,box,scene,aspect,ratio,scale,side);if(box){const a=anchor(box);p.x=M.clamp(a.x-p.w*p.target.x,0,1-p.w);p.y=M.clamp(a.y-p.h*p.target.y,0,1-p.h);const axis=M.axis(scene);if(mode==='symmetry'&&axis!==null)p.x=M.clamp(axis-p.w/2,0,1-p.w)}
  for(const dx of [-.05,0,.05])for(const dy of [-.05,0,.05]){let q={...p,x:M.clamp(p.x+dx,0,1-p.w),y:M.clamp(p.y+dy,0,1-p.h)};q.quality=score(q,box,scene,mode);if(!best||q.quality>best.quality)best=q}
 }let head=protectedHead(box);best.clipped=!!head&&(head.x<best.x||head.x+head.w>best.x+best.w||head.y<best.y||head.y+head.h>best.y+best.h);return best}
 function coach(box,scene,mode,side,reference){if(!box)return {key:'none',text:'Sélectionne un sujet pour être guidé.'};let a=anchor(box),t=reference||M.target(mode,scene,side),axis=!reference&&mode==='symmetry'?M.axis(scene):null,dx=(axis??a.x)-t.x,dy=a.y-t.y;if(Math.abs(dx)>.07)return {key:dx>0?'right':'left',text:dx>0?'Pivote doucement vers la droite →':'← Pivote doucement vers la gauche'};if(Math.abs(dy)>.07)return {key:dy>0?'down':'up',text:dy>0?'Incline légèrement vers le bas ↓':'Incline légèrement vers le haut ↑'};return {key:'ready',text:'Orientation en place — vérifie les bords du cadre.'}}
 root.CineScene={measure,anchor,protectedHead,score,propose,coach};
})(typeof self!=='undefined'?self:globalThis);
