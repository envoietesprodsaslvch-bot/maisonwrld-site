/* Classic worker: inference never runs on the live monitor UI thread. */
importScripts('composition.js','scene-engine.js');
let detector,faceDetector,faceAvailable=false;
async function init(){try{
 const {FilesetResolver,ObjectDetector,FaceDetector}=await import('./vendor/vision_bundle.mjs');
 const files=await FilesetResolver.forVisionTasks(new URL('./vendor/wasm',self.location.href).href);
 detector=await ObjectDetector.createFromOptions(files,{baseOptions:{modelAssetPath:new URL('./vendor/efficientdet_lite0.tflite',self.location.href).href,delegate:'CPU'},runningMode:'IMAGE',scoreThreshold:.48,maxResults:12});
 try{faceDetector=await FaceDetector.createFromOptions(files,{baseOptions:{modelAssetPath:new URL('./vendor/blaze_face_short_range.tflite',self.location.href).href,delegate:'CPU'},runningMode:'IMAGE',minDetectionConfidence:.6});faceAvailable=true}catch(e){/* Object detection remains usable without the optional face model. */}
 postMessage({type:'ready',faceAvailable});
 }catch(e){postMessage({type:'error',message:String(e.message||e)})}}
onmessage=async({data})=>{if(data.type!=='frame')return;const {bitmap,epoch,id}=data;try{
 if(!detector)throw Error('Modèle indisponible');let start=performance.now(),w=bitmap.width,h=bitmap.height;
 const results=detector.detect(bitmap),objects=results.detections.map(d=>{const b=d.boundingBox,c=d.categories[0];return{x:b.originX/w,y:b.originY/h,w:b.width/w,h:b.height/h,label:c.categoryName,score:c.score}});
 const faces=faceDetector?faceDetector.detect(bitmap).detections.map(d=>{const b=d.boundingBox,eyes=d.keypoints?.slice(0,2);return{x:b.originX/w,y:b.originY/h,w:b.width/w,h:b.height/h,eyeY:eyes?.length===2?(eyes[0].y+eyes[1].y)/2:undefined,score:d.categories[0].score}}):[];
 for(const face of faces){const matches=objects.filter(b=>b.label==='person'&&face.x+face.w/2>=b.x&&face.x+face.w/2<=b.x+b.w&&face.y+face.h/2>=b.y&&face.y+face.h/2<=b.y+b.h).sort((a,b)=>a.w*a.h-b.w*b.h);if(matches[0]&&(!matches[0].face||matches[0].face.score<face.score))matches[0].face=face}
 const c=new OffscreenCanvas(240,Math.max(1,Math.round(h/w*240))),cx=c.getContext('2d',{willReadFrequently:true});cx.drawImage(bitmap,0,0,c.width,c.height);
 const scene=CineMath.analyze(cx.getImageData(0,0,c.width,c.height).data,c.width,c.height);
 Object.assign(scene,CineScene.measure(cx.getImageData(0,0,c.width,c.height).data,c.width,c.height,objects));scene.faces=faces;scene.faceAvailable=faceAvailable;
 postMessage({type:'result',objects,scene,epoch,id,ms:Math.round(performance.now()-start)});
 }catch(e){postMessage({type:'frame-error',epoch,id,message:String(e.message||e)})}finally{bitmap.close()}};
init();
